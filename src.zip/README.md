# MyWebsite

This is a website about myself that I created using Bootstrap. It was a neat way to learn html and how a website is created.

Website is at thomasthansen.com

Can be comiled by running npm start
